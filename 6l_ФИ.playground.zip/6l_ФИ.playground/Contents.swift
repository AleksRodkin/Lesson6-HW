import Foundation

//1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.
//2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример: filter для массивов)
//3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.

enum Gender: String {
    case male = "мужской"
    case female = "женский"
}

enum DogsBreed: String {
    case pug = "мопс"
    case poodle = "пудель"
    case shepherd = "овчарка"
}

class People {
    var gender: Gender
    var age: Int
    
    init(gender: Gender, age: Int) {
        self.gender = gender
        self.age = age
    }
}

class Dogs {
    var breed: DogsBreed
    var age: Int
    
    init(breed: DogsBreed, age: Int){
        self.breed = breed
        self.age = age
    }
}

extension People {
    var printPeopleInfo: String {
        "Пол: \(gender.rawValue), возраст: \(age)"
    }
}

extension Dogs {
    var printDogsInfo: String {
        "Порода: \(breed.rawValue), возраст: \(age)"
    }
}

struct GenericQueue<T> {
  
    var positionInQueue: [T] = []
    
    func filter(predicate: (T) -> Bool) -> [T] {
        var tempArray: [T] = []
        for element in positionInQueue {
            if predicate(element) {
                tempArray.append(element)
            }
        }
        return tempArray
    }
    
    mutating func push(_ position: T){
        positionInQueue.append(position)
    }
    
    mutating func pop() -> T? {
        guard positionInQueue.count > 0 else { return nil }
        return positionInQueue.removeFirst()
    }
}

extension GenericQueue {
    subscript(index: Int) -> T? {
        guard index >= 0 && index < positionInQueue.count
        else {
            return nil
        }
        return positionInQueue[index]
    }
}

var queuePeople = GenericQueue<People>()
var queueDogs = GenericQueue<Dogs>()

queuePeople.push(People(gender: .male, age: 28))
queueDogs.push(Dogs(breed: .shepherd, age: 8))
queuePeople.push(People(gender: .female, age: 20))
queuePeople.push(People(gender: .male, age: 55))
queueDogs.push(Dogs(breed: .poodle, age: 2))
queueDogs.push(Dogs(breed: .pug, age: 3))

//queuePeople.pop()
//queuePeople.pop()
//queuePeople.pop()
//queuePeople.pop()
//queuePeople.pop()

// Закоментировал pop, потому что filterPeople выводит пустой массив


var filterPeople = queuePeople.filter() { element in element.age > 21 }
filterPeople.forEach { print($0.printPeopleInfo) }

var filterDogs = queueDogs.filter() { element in element.age > 2 }
filterDogs.forEach { print($0.printDogsInfo) }

// к этому моменту я понял, что наверное зря еще сделал очередь собак, ведь в итоге имеем две разные очереди, а не одну общую


queuePeople[0]
queueDogs[0]
